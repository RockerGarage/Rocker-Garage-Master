
# Rocker Garage – Launch Core

This bundle includes:
- `index.html` Coming Soon teaser wired to S3 assets via `rg.config.json`
- Simple chat page stubs in `/pages` for Axe, Nyxx, Torque
- Shared CSS in `/assets/css/rg.css`
- Local avatar placeholders in `/assets/img` (swap in WP)

## Configure S3 assets
Edit `rg.config.json` to point at your S3 files. Current defaults expect:
- Background: https://rocker-garage-assets.s3.amazonaws.com/rg/prod/img/background.png
- OGG audio: https://rocker-garage-assets.s3.amazonaws.com/rg/prod/audio/axe_intro.ogg
- MP3 audio: https://rocker-garage-assets.s3.amazonaws.com/rg/prod/audio/axe_intro.mp3

If your files live under `RockerGarage_FinalPro_v7/rg-upload/`, set `S3_PREFIX_PROD` in `rg.config.json` to `RockerGarage_FinalPro_v7/rg-upload`.

## WordPress (AI Engine) pages
Create WP pages for Axe, Nyxx, Torque and embed with your `mwai_chatbot` shortcode. Use final avatars in the WP Media Library.

## Optional: Host this bundle on S3
Upload the folder contents to `s3://rocker-garage-assets/rg/prod/build/` (or staging). Ensure CORS & bucket policy allow public-read for `rg/*`.
