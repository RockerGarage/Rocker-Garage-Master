
Rocker Garage — Full Intro Pro Mode (v7)
========================================
What’s inside
- index.html
- assets/css/style.css
- assets/js/main.js
- docs/RG_SiteMap_Assets_v1_large.pdf (if provided)

How to use
1) Unzip over your working folder.
2) Open index.html and click once to unlock audio.

S3 assets used
- Background: https://rocker-garage-assets.s3.amazonaws.com/rg/prod/img/rg_bg_garage_v7.png
- Headlights: https://rocker-garage-assets.s3.amazonaws.com/rg/prod/img/rg_bg_headlights_v3.png
- Logo:       https://rocker-garage-assets.s3.amazonaws.com/rg/prod/img/rg_logo_main_v7.png
- Slogan:     https://rocker-garage-assets.s3.amazonaws.com/rg/prod/img/rg_slogan_main_v7.png
- Enter:      https://rocker-garage-assets.s3.amazonaws.com/rg/prod/img/rg_enter_btn_v7.png
- Amp hum:    https://rocker-garage-assets.s3.amazonaws.com/rg/prod/audio/rg_audio_amp_hum_v2.ogg
- V8 rev:     https://rocker-garage-assets.s3.amazonaws.com/rg/prod/audio/rg_audio_v8_rev_v1.ogg

Generated: 2025-08-09T22:17:39.310877Z
