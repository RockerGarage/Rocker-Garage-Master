(function(){
  const $ = (s)=>document.querySelector(s);
  const logo = $('#logo');
  const slogan = $('#slogan');
  const enterBtn = $('#enter');
  const headlights = $('#headlights');
  const ampHum = $('#ampHum');
  const v8Rev  = $('#v8Rev');

  // --- Headlight pulse helper ---
  function pulseHL(dUp=0.32, peak=0.9){
    if (!headlights) return;
    gsap.fromTo(headlights, {opacity:0.14}, {opacity:peak, duration:dUp, yoyo:true, repeat:1, ease:"power2.out"});
  }

  // --- Hum start (WebAudio gain fade, with fallback) + drive neon CSS var ---
  let humCtx, humGain, humPulsing=false;
  function bootHum(){
    try{
      if(!humCtx) humCtx = new (window.AudioContext||window.webkitAudioContext)();
      const src = humCtx.createMediaElementSource(ampHum);
      humGain = humCtx.createGain();
      src.connect(humGain).connect(humCtx.destination);
      humGain.gain.value = 0.0;
      ampHum.play().catch(()=>{});
      gsap.to(humGain.gain, { value:0.35, duration:1.8, ease:"power2.out" });
      startHumPulse(false);
    }catch(e){ startHumPulse(true); }
  }
  function startHumPulse(fallback=false){
    if(humPulsing) return; humPulsing=true;
    const neon={v:18}; const base=0.28, peak=0.52;
    gsap.ticker.add(()=>document.documentElement.style.setProperty('--neon', neon.v+'px'));
    const tl=gsap.timeline({repeat:-1,yoyo:true,defaults:{ease:'sine.inOut'}});
    tl.add('up');
    if(fallback) tl.to(ampHum,{volume:0.8,duration:0.9},'up');
    else         tl.to(humGain.gain,{value:peak,duration:0.9},'up');
    tl.to(neon,{v:34,duration:0.9},'up');
    tl.add('down');
    if(fallback) tl.to(ampHum,{volume:0.35,duration:0.9},'down');
    else         tl.to(humGain.gain,{value:base,duration:0.9},'down');
    tl.to(neon,{v:18,duration:0.9},'down');
  }
  window.addEventListener('click',()=>{ if(ampHum && ampHum.paused) bootHum(); },{once:true});

  function startMain(){
    bootHum();
    const warm=gsap.timeline();
    warm.to(headlights,{opacity:0.00,duration:.08})
        .to(headlights,{opacity:0.48,duration:.10})
        .to(headlights,{opacity:0.10,duration:.12})
        .to(headlights,{opacity:0.66,duration:.14})
        .to(headlights,{opacity:0.16,duration:.16})
        .to(headlights,{opacity:0.74,duration:.18})
        .to(headlights,{opacity:0.24,duration:.22})
        .to(headlights,{opacity:0.82,duration:.28})
        .to(headlights,{opacity:0.30,duration:.30})
        .to(headlights,{opacity:0.90,duration:.36})
        .to(headlights,{opacity:0.52,duration:.50});

    const tl=gsap.timeline({defaults:{ease:'power4.inOut'}});
    tl.fromTo(logo,{opacity:0,scale:0.98},{opacity:1,duration:0.8})
      .to(logo,{duration:5.0,scale:1.45,rotateY:1080,filter:"drop-shadow(0 0 12px #fff) drop-shadow(0 0 20px #eee)"},">-0.1")
      .to(logo,{duration:1.8,scale:1.56,filter:"drop-shadow(0 0 30px #fff) drop-shadow(0 0 52px #d9d9d9)"},">-0.2")
      .add(warm,"-=4.2")
      .to(slogan,{opacity:1,duration:1.0},">-0.1")
      .to(slogan,{filter:"drop-shadow(0 0 16px #fff)",duration:.4})
      .to(slogan,{opacity:0,duration:1.2,delay:.7})
      .to(logo,{filter:"drop-shadow(0 0 36px #fff) drop-shadow(0 0 64px #cfcfcf)",duration:.5},"<")
      .to(enterBtn,{opacity:1,duration:1.1,onComplete:()=>enterBtn.classList.add('pulse')});
  }

  function synthIntroThenStart(){
    const pre=gsap.timeline();
    pre.add(()=>pulseHL(.28,.75),.30)
       .add(()=>pulseHL(.30,.80),1.00)
       .add(()=>pulseHL(.32,.85),1.70)
       .add(()=>pulseHL(.45,.95),2.50)
       .add(startMain,3.0);
  }

  (function kickoff(){
    if(!window.gsap){ console.error("GSAP missing"); return; }
    if(!v8Rev){ synthIntroThenStart(); return; }
    const tryPlay=()=>{ v8Rev.currentTime=0;
      v8Rev.play().then(()=>{
        const d=isFinite(v8Rev.duration)?v8Rev.duration:3.0;
        const beats=[.10,.35,.70,Math.max(.95,d-.40)];
        beats.forEach((t,i)=>setTimeout(()=>pulseHL(i<3?.32:.48,i<3?.85:.97),t*1000));
        v8Rev.addEventListener('ended',startMain,{once:true});
      }).catch(()=>synthIntroThenStart());
    };
    v8Rev.addEventListener('canplaythrough',tryPlay,{once:true});
    v8Rev.addEventListener('error',synthIntroThenStart,{once:true});
    setTimeout(()=>{ if(v8Rev.paused) synthIntroThenStart(); },1000);
  })();
})();
