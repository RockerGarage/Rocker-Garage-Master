#!/usr/bin/env bash
set -euo pipefail
: "${BUCKET:=rocker-garage-assets}"
: "${PREFIX:=rg}"
aws s3 cp "./" "s3://$BUCKET/$PREFIX/upload/build/team/" --recursive   --exclude "*" --include "index.html" --include "styles.css" --include "app.js"   --content-type "text/plain"
aws s3 cp "index.html" "s3://$BUCKET/$PREFIX/upload/build/team/index.html" --content-type "text/html"
aws s3 cp "styles.css" "s3://$BUCKET/$PREFIX/upload/build/team/styles.css" --content-type "text/css"
aws s3 cp "app.js"     "s3://$BUCKET/$PREFIX/upload/build/team/app.js"     --content-type "application/javascript"
echo "✅ Staged to s3://$BUCKET/$PREFIX/upload/build/team/"
