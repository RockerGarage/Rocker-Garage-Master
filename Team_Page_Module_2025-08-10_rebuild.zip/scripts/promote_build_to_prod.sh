#!/usr/bin/env bash
set -euo pipefail
: "${BUCKET:=rocker-garage-assets}"
: "${PREFIX:=rg}"
echo "Dry run: upload/build/team -> prod/build/team"
aws s3 sync "s3://$BUCKET/$PREFIX/upload/build/team/" "s3://$BUCKET/$PREFIX/prod/build/team/" --dryrun
read -p "Proceed with promotion? (yes/no) " ans
if [[ "$ans" == "yes" ]]; then
  aws s3 sync "s3://$BUCKET/$PREFIX/upload/build/team/" "s3://$BUCKET/$PREFIX/prod/build/team/"
  echo "✅ Promotion complete."
fi
