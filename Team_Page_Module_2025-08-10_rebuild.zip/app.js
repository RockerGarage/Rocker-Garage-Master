/* Rocker Garage — Team Page Module JS */
(function(){
  const cards = document.querySelectorAll('.rg-card');
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Idle breathe loop with GSAP
  if (!prefersReducedMotion && window.gsap) {
    cards.forEach(card => {
      const img = card.querySelector('.rg-avatar');
      gsap.to(img, {
        keyframes: [
          { yPercent: -1.5, scale: 1.015, duration: 1.6, ease: "sine.inOut" },
          { yPercent: 0,    scale: 1.000, duration: 1.6, ease: "sine.inOut" }
        ],
        repeat: -1, yoyo: true, delay: Math.random() * 0.8
      });
    });
  }

  // Parallax tilt
  cards.forEach(card => {
    const wrap = card.querySelector('.rg-tilt');
    const img = card.querySelector('.rg-avatar');
    if (!wrap || !img) return;
    let rect;
    function onEnter(){ rect = wrap.getBoundingClientRect(); }
    function onMove(e){
      if (prefersReducedMotion) return;
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;
      const rx = (0.5 - y) * 8;
      const ry = (x - 0.5) * 8;
      gsap.to(img, { rotateX: rx, rotateY: ry, transformPerspective: 800, duration: 0.25, ease: "sine.out" });
    }
    function onLeave(){ if (prefersReducedMotion) return; gsap.to(img, { rotateX: 0, rotateY: 0, duration: 0.35, ease: "sine.out" }); }
    wrap.addEventListener('pointerenter', onEnter);
    wrap.addEventListener('pointermove', onMove);
    wrap.addEventListener('pointerleave', onLeave);
  });

  // Bio panels
  function openPanel(sel, btn){
    const panel = document.querySelector(sel);
    if (!panel) return;
    panel.hidden = false;
    btn?.setAttribute('aria-expanded', 'true');
    if (window.gsap && !prefersReducedMotion) {
      gsap.fromTo(panel.querySelector('.rg-bio-panel'), { y: 30, opacity: 0 }, { y: 0, opacity: 1, duration: 0.35, ease: "sine.out" });
    }
  }
  function closePanel(sel){
    const panel = document.querySelector(sel);
    if (!panel) return;
    if (window.gsap && !prefersReducedMotion) {
      gsap.to(panel.querySelector('.rg-bio-panel'), { y: 20, opacity: 0, duration: 0.25, ease: "sine.in", onComplete: () => { panel.hidden = true; } });
    } else {
      panel.hidden = true;
    }
    document.querySelectorAll(`.rg-bio-btn[data-target="${sel}"]`).forEach(b => b.setAttribute('aria-expanded','false'));
  }
  document.querySelectorAll('.rg-bio-btn').forEach(btn => btn.addEventListener('click', () => openPanel(btn.getAttribute('data-target'), btn)));
  document.querySelectorAll('.rg-close').forEach(btn => btn.addEventListener('click', () => closePanel(btn.getAttribute('data-target'))));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') document.querySelectorAll('.rg-bio:not([hidden])').forEach(p => p.hidden = true); });
  window.RG_TEAM_MODULE_READY = true;
})();