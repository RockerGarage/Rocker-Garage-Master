Rocker Garage — Team Page Animation Module
Date: 2025-08-10

What this is
- Standalone module with hover tilt/parallax, idle "breathe" loop, and bio reveal on click.
- Uses GSAP from CDN; no build step required.
- Avatars load from your S3 prod/img canonical paths.

Files
- index.html
- styles.css
- app.js
- scripts/upload_build_to_s3_upload.sh
- scripts/promote_build_to_prod.sh

Deploy (staging -> prod)
export BUCKET=rocker-garage-assets
export PREFIX=rg
chmod +x scripts/upload_build_to_s3_upload.sh && ./scripts/upload_build_to_s3_upload.sh
# Review: https://rocker-garage-assets.s3.amazonaws.com/rg/upload/build/team/index.html
chmod +x scripts/promote_build_to_prod.sh && ./scripts/promote_build_to_prod.sh
