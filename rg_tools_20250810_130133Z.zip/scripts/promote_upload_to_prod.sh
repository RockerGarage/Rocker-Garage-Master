#!/usr/bin/env bash
set -euo pipefail

: "${BUCKET:=rocker-garage-assets}"
: "${PREFIX:=rg}"

echo "Dry run: upload/ -> prod/audio"
aws s3 sync "s3://$BUCKET/$PREFIX/upload/audio/" "s3://$BUCKET/$PREFIX/prod/audio/" --dryrun

read -p "Proceed with promotion? (yes/no) " ans
if [[ "$ans" == "yes" ]]; then
  aws s3 sync "s3://$BUCKET/$PREFIX/upload/audio/" "s3://$BUCKET/$PREFIX/prod/audio/"     --content-type audio/ogg --cache-control "public, max-age=31536000, immutable"
  echo "✅ Promotion complete."
else
  echo "Aborted."
fi
