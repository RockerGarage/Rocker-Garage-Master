#!/usr/bin/env bash
set -euo pipefail

: "${BUCKET:=rocker-garage-assets}"
: "${PREFIX:=rg}"

mkdir -p _tmp_upload_audio
shopt -s nullglob
for f in *.ogg; do
  cp -f "$f" "_tmp_upload_audio/"
done

aws s3 cp "_tmp_upload_audio/" "s3://$BUCKET/$PREFIX/upload/audio/" --recursive   --exclude "*" --include "*.ogg"   --content-type "audio/ogg" --cache-control "public, max-age=31536000, immutable"

echo "✅ Staged OGGs to s3://$BUCKET/$PREFIX/upload/audio/"
