#!/usr/bin/env bash
set -euo pipefail

# Convert all MP3s in current dir to OGG (Vorbis) at quality 5 (~160-192 kbps)
for f in *.mp3; do
  [ -f "$f" ] || continue
  out="${f%.mp3}.ogg"
  echo "Converting $f -> $out"
  ffmpeg -y -i "$f" -c:a libvorbis -q:a 5 "$out"
done

echo "Done. Verify with: ffprobe -hide_banner *.ogg"
