Rocker Garage — Audio Prep & Promotion Toolkit
Date: 2025-08-10 13:01:33Z

Contents
- rg_validation_log.txt          : Validation results for the current workspace
- scripts/convert_to_ogg.sh      : Batch-convert MP3 -> OGG (Vorbis q=5)
- scripts/upload_to_s3_upload.sh : Upload OGGs to s3://rocker-garage-assets/rg/upload/audio/
- scripts/promote_upload_to_prod.sh : Promote /upload/audio -> /prod/audio (with proper metadata)

Usage
1) Conversion (run where your MP3s live)
   chmod +x scripts/convert_to_ogg.sh && ./scripts/convert_to_ogg.sh

2) Stage to S3 /upload
   export BUCKET=rocker-garage-assets
   export PREFIX=rg
   chmod +x scripts/upload_to_s3_upload.sh && ./scripts/upload_to_s3_upload.sh

3) Review in browser (optional)
   https://rocker-garage-assets.s3.amazonaws.com/rg/upload/audio/<yourfile>.ogg

4) Promote to /prod (after review)
   chmod +x scripts/promote_upload_to_prod.sh && ./scripts/promote_upload_to_prod.sh

Notes
- No prod overwrites happen until you confirm promotion inside the script.
- All uploads set Cache-Control: public, max-age=31536000, immutable and Content-Type: audio/ogg.
- Validation rule: no file < 1.1222KB, PNGs must be valid. Audio presence is listed but full decode is not performed here.
