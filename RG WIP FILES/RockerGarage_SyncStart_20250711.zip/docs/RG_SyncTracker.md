# Rocker Garage Sync Tracker

- Created: 2025-08-07
- Version: SyncStart_20250711
- Contents:
  - index.html (Coming Soon page)
  - 3 avatars (Axe, Nyxx, Torque)
  - Voice intros (MP3 + OGG)
